import About from './About';
import './App.css';
import Contact from './Contact';
import Home from './Home';
import Master from './Master';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Services from './Services';

function App() {
  return (
    <div className="App">
      <BrowserRouter >
        <Routes>
          <Route path="/" element={<Master />} >
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/services" element={<Services />} />
            {/* <Route path="/login" element={<Login />} /> */}

          </Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
