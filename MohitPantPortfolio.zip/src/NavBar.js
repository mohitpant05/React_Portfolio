import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar() {
    return (
        <div>
            <header className="s-header">
                <div className="row s-header__inner width-sixteen-col">
                    <div className="s-header__block">
                        <div className="s-header__logo">
                            <Link className="logo" to="/home">
                                <span><h4 className='logo'>Mohit.</h4></span>
                            </Link>
                        </div>
                        <a className="s-header__menu-toggle" href="#0">
                            <span>Menu</span>
                        </a>
                    </div>{" "}
                    {/* end s-header__block */}
                    <nav className="s-header__nav">
                        <ul className="s-header__menu-links">
                            <li>
                                <Link to="/about">About</Link>
                            </li>
                            <li>
                                <Link to="/services">Services</Link>
                            </li>

                            <li>
                                <Link to="/contact">Contact</Link>
                            </li>
                        </ul>{" "}
                        {/* s-header__menu-links */}
                        <div className="s-header__contact">
                            <Link
                                to="/contact"
                                className="btn btn--primary s-header__contact-btn"
                            >
                                Let's Work Together
                            </Link>
                        </div>{" "}
                        {/* s-header__contact */}
                    </nav>{" "}
                    {/* end s-header__nav */}
                </div>{" "}
                {/* end s-header__inner */}
            </header >

        </div >
    )
}
