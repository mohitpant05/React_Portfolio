import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div>
      <section>
        {/* end s-intro */}
        {/* about
        ----------------------------------------------- */}
        <section id="about" className="s-about target-section">
          <div className="row s-about__content width-sixteen-col">
            <div className="column grid-block grid-section-split">
              <img
                src="images/geometric_shape.svg"
                alt=""
                className="s-about__content-imgbg"
              />
              <div className="section-header grid-section-split__header">
                <div className="text-pretitle">Summary</div>
                <h2 className="text-display-title">
                  A great learner Mohit Pant
                </h2>
              </div>{" "}
              {/* end section-header */}
              <div className="s-about__content-main grid-section-split__primary">
                <p className="attention-getter">
                Software engineers are the vanguards of the digital realm, wielding their mastery of code and algorithms to shape the world around us. In a landscape where technology permeates every aspect of our lives, from the devices we use to the infrastructure we rely upon, software engineers are the architects of this digital age.
                </p>
                <p className="attention-getter">
                At the core of their craft lies a potent blend of logic, creativity, and technical expertise. They are the alchemists who transmute abstract concepts into tangible solutions, using programming languages as their medium of creation. With each keystroke, they sculpt the intricate frameworks that power our modern society, from the algorithms that optimize search engines to the operating systems that govern our devices.
                </p>
                <p className="attention-getter">
                But their role extends far beyond mere code. Software engineers are problem solvers, tasked with unraveling the complexities of our interconnected world and devising elegant solutions to a myriad of challenges. Whether it's developing software to streamline business operations, designing user interfaces to enhance the digital experience, or creating algorithms to analyze vast troves of data, their ingenuity knows no bounds
                </p>
              </div>{" "}
              {/* end s-about__content-main */}
              <div className="s-about__content-btn grid-section-split__bottom">
                <Link  to={"/about"} className="btn btn--stroke u-fullwidth">
                  More About Me
                </Link>
                <ul className="s-about__social social-list">
                  <li>
                    <a href="#0">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={24}
                        height={24}
                        viewBox="0 0 24 24"
                        style={{
                          fill: "rgba(0, 0, 0, 1)",
                          transform: "",
                          msFilter: ""
                        }}
                      >
                        <path d="M20,3H4C3.447,3,3,3.448,3,4v16c0,0.552,0.447,1,1,1h8.615v-6.96h-2.338v-2.725h2.338v-2c0-2.325,1.42-3.592,3.5-3.592 c0.699-0.002,1.399,0.034,2.095,0.107v2.42h-1.435c-1.128,0-1.348,0.538-1.348,1.325v1.735h2.697l-0.35,2.725h-2.348V21H20 c0.553,0,1-0.448,1-1V4C21,3.448,20.553,3,20,3z" />
                      </svg>
                      <span className="u-screen-reader-text">Facebook</span>
                    </a>
                  </li>
                  <li>
                    <a href="#0">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={24}
                        height={24}
                        viewBox="0 0 24 24"
                        style={{
                          fill: "rgba(0, 0, 0, 1)",
                          transform: "",
                          msFilter: ""
                        }}
                      >
                        <path d="M19.633,7.997c0.013,0.175,0.013,0.349,0.013,0.523c0,5.325-4.053,11.461-11.46,11.461c-2.282,0-4.402-0.661-6.186-1.809 c0.324,0.037,0.636,0.05,0.973,0.05c1.883,0,3.616-0.636,5.001-1.721c-1.771-0.037-3.255-1.197-3.767-2.793 c0.249,0.037,0.499,0.062,0.761,0.062c0.361,0,0.724-0.05,1.061-0.137c-1.847-0.374-3.23-1.995-3.23-3.953v-0.05 c0.537,0.299,1.16,0.486,1.82,0.511C3.534,9.419,2.823,8.184,2.823,6.787c0-0.748,0.199-1.434,0.548-2.032 c1.983,2.443,4.964,4.04,8.306,4.215c-0.062-0.3-0.1-0.611-0.1-0.923c0-2.22,1.796-4.028,4.028-4.028 c1.16,0,2.207,0.486,2.943,1.272c0.91-0.175,1.782-0.512,2.556-0.973c-0.299,0.935-0.936,1.721-1.771,2.22 c0.811-0.088,1.597-0.312,2.319-0.624C21.104,6.712,20.419,7.423,19.633,7.997z" />
                      </svg>
                      <span className="u-screen-reader-text">Twitter</span>
                    </a>
                  </li>
                  <li>
                    <a href="#0">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={24}
                        height={24}
                        viewBox="0 0 24 24"
                        style={{
                          fill: "rgba(0, 0, 0, 1)",
                          transform: "",
                          msFilter: ""
                        }}
                      >
                        <path d="M11.999,7.377c-2.554,0-4.623,2.07-4.623,4.623c0,2.554,2.069,4.624,4.623,4.624c2.552,0,4.623-2.07,4.623-4.624 C16.622,9.447,14.551,7.377,11.999,7.377L11.999,7.377z M11.999,15.004c-1.659,0-3.004-1.345-3.004-3.003 c0-1.659,1.345-3.003,3.004-3.003s3.002,1.344,3.002,3.003C15.001,13.659,13.658,15.004,11.999,15.004L11.999,15.004z" />
                        <circle cx="16.806" cy="7.207" r="1.078" />
                        <path d="M20.533,6.111c-0.469-1.209-1.424-2.165-2.633-2.632c-0.699-0.263-1.438-0.404-2.186-0.42 c-0.963-0.042-1.268-0.054-3.71-0.054s-2.755,0-3.71,0.054C7.548,3.074,6.809,3.215,6.11,3.479C4.9,3.946,3.945,4.902,3.477,6.111 c-0.263,0.7-0.404,1.438-0.419,2.186c-0.043,0.962-0.056,1.267-0.056,3.71c0,2.442,0,2.753,0.056,3.71 c0.015,0.748,0.156,1.486,0.419,2.187c0.469,1.208,1.424,2.164,2.634,2.632c0.696,0.272,1.435,0.426,2.185,0.45 c0.963,0.042,1.268,0.055,3.71,0.055s2.755,0,3.71-0.055c0.747-0.015,1.486-0.157,2.186-0.419c1.209-0.469,2.164-1.424,2.633-2.633 c0.263-0.7,0.404-1.438,0.419-2.186c0.043-0.962,0.056-1.267,0.056-3.71s0-2.753-0.056-3.71C20.941,7.57,20.801,6.819,20.533,6.111z M19.315,15.643c-0.007,0.576-0.111,1.147-0.311,1.688c-0.305,0.787-0.926,1.409-1.712,1.711c-0.535,0.199-1.099,0.303-1.67,0.311 c-0.95,0.044-1.218,0.055-3.654,0.055c-2.438,0-2.687,0-3.655-0.055c-0.569-0.007-1.135-0.112-1.669-0.311 c-0.789-0.301-1.414-0.923-1.719-1.711c-0.196-0.534-0.302-1.099-0.311-1.669c-0.043-0.95-0.053-1.218-0.053-3.654 c0-2.437,0-2.686,0.053-3.655c0.007-0.576,0.111-1.146,0.311-1.687c0.305-0.789,0.93-1.41,1.719-1.712 c0.534-0.198,1.1-0.303,1.669-0.311c0.951-0.043,1.218-0.055,3.655-0.055c2.437,0,2.687,0,3.654,0.055 c0.571,0.007,1.135,0.112,1.67,0.311c0.786,0.303,1.407,0.925,1.712,1.712c0.196,0.534,0.302,1.099,0.311,1.669 c0.043,0.951,0.054,1.218,0.054,3.655c0,2.436,0,2.698-0.043,3.654H19.315z" />
                      </svg>
                      <span className="u-screen-reader-text">Instagram</span>
                    </a>
                  </li>
                  <li>
                    <a href="#0">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={24}
                        height={24}
                        viewBox="0 0 24 24"
                        style={{
                          fill: "rgba(0, 0, 0, 1)",
                          transform: "",
                          msfilter: ""
                        }}
                      >
                        <path d="M20.66 6.98a9.932 9.932 0 0 0-3.641-3.64C15.486 2.447 13.813 2 12 2s-3.486.447-5.02 1.34c-1.533.893-2.747 2.107-3.64 3.64S2 10.187 2 12s.446 3.487 1.34 5.02a9.924 9.924 0 0 0 3.641 3.64C8.514 21.553 10.187 22 12 22s3.486-.447 5.02-1.34a9.932 9.932 0 0 0 3.641-3.64C21.554 15.487 22 13.813 22 12s-.446-3.487-1.34-5.02zM12 3.66c2 0 3.772.64 5.32 1.919-.92 1.174-2.286 2.14-4.1 2.9-1.002-1.813-2.088-3.327-3.261-4.54A7.715 7.715 0 0 1 12 3.66zM5.51 6.8a8.116 8.116 0 0 1 2.711-2.22c1.212 1.201 2.325 2.7 3.34 4.5-2 .6-4.114.9-6.341.9-.573 0-1.006-.013-1.3-.04A8.549 8.549 0 0 1 5.51 6.8zM3.66 12c0-.054.003-.12.01-.2.007-.08.01-.146.01-.2.254.014.641.02 1.161.02 2.666 0 5.146-.367 7.439-1.1.187.373.381.793.58 1.26-1.32.293-2.674 1.006-4.061 2.14S6.4 16.247 5.76 17.5c-1.4-1.587-2.1-3.42-2.1-5.5zM12 20.34c-1.894 0-3.594-.587-5.101-1.759.601-1.187 1.524-2.322 2.771-3.401 1.246-1.08 2.483-1.753 3.71-2.02a29.441 29.441 0 0 1 1.56 6.62 8.166 8.166 0 0 1-2.94.56zm7.08-3.96a8.351 8.351 0 0 1-2.58 2.621c-.24-2.08-.7-4.107-1.379-6.081.932-.066 1.765-.1 2.5-.1.799 0 1.686.034 2.659.1a8.098 8.098 0 0 1-1.2 3.46zm-1.24-5c-1.16 0-2.233.047-3.22.14a27.053 27.053 0 0 0-.68-1.62c2.066-.906 3.532-2.006 4.399-3.3 1.2 1.414 1.854 3.027 1.96 4.84-.812-.04-1.632-.06-2.459-.06z" />
                      </svg>
                      <span className="u-screen-reader-text">Dribbble</span>
                    </a>
                  </li>
                </ul>{" "}
                {/* end s-footer__social */}
              </div>{" "}
              {/* end s-about__content-btn */}
            </div>{" "}
            {/* content-inner */}
          </div>
        </section>{" "}
        {/* end s-about */}
        {/* expertise
        ----------------------------------------------- */}
        <section id="expertise" className="s-expertise">
          <div className="row s-expertise__content width-sixteen-col">
            <div className="column xl-12 grid-block grid-section-split">
              <div className="section-header grid-section-split__header">
                <div className="text-pretitle">Expertise</div>
                <h2 className="text-display-title">My key areas of expertise.</h2>
                <p className="lead">
                Key areas of expertise include proficiency in programming languages such as Java, Python, or C++, expertise in software development methodologies like Agile or Scrum, adeptness in problem-solving and algorithmic thinking, familiarity with databases and data structures, mastery of software testing and debugging techniques, understanding of computer networks and cybersecurity principles, proficiency in version control systems like Git, competence in web development frameworks such as React or Angular, knowledge of cloud computing platforms like AWS or Azure, and the ability to collaborate effectively in interdisciplinary teams while adhering to ethical and professional standards. These multifaceted competencies equip software engineers to tackle diverse challenges and innovate solutions in a rapidly evolving digital landscape.
                </p>
              </div>{" "}
              {/* end section-header */}
              <div className="s-expertise__content-main grid-section-split__primary">
                <div className="grid-list-items list-items show-ctr">
                  <div className="grid-list-items__item list-items__item">
                    <div className="grid-list-items__title list-items__item-header">
                      <h3 className="list-items__item-title">Digital Marketing</h3>
                    </div>
                    <div className="grid-list-items__text list-items__item-text">
                      <p>
                      Digital marketing is the strategic use of online platforms and technologies to promote products, services, or brands. It encompasses various channels such as social media, search engines, email, and websites. Key components include search engine optimization (SEO), content marketing, social media marketing, email marketing, pay-per-click (PPC) advertising, and analytics. It leverages data and analytics to target specific audiences, optimize campaigns, and measure performance, fostering engagement and driving conversions in the digital space.
                      </p>
                    </div>
                  </div>{" "}
                  {/* list-item */}
                  <div className="grid-list-items__item list-items__item">
                    <div className="grid-list-items__title list-items__item-header">
                      <h3 className="list-items__item-title">Project Management</h3>
                    </div>
                    <div className="grid-list-items__text list-items__item-text">
                      <p>
                      Project management involves planning, organizing, and overseeing the execution of tasks and resources to achieve specific goals within constraints such as time, budget, and scope. It encompasses defining objectives, creating schedules, allocating resources, managing risks, and communicating with stakeholders. Key methodologies include Agile, Scrum, and Waterfall. Effective project managers possess skills in leadership, communication, problem-solving, and conflict resolution, ensuring projects are delivered on time, within budget, and to stakeholder satisfaction.
                      </p>
                    </div>
                  </div>{" "}
                  {/* list-expertise__item */}
                  <div className="grid-list-items__item list-items__item">
                    <div className="grid-list-items__title list-items__item-header">
                      <h3 className="list-items__item-title">Content Marketing</h3>
                    </div>
                    <div className="grid-list-items__text list-items__item-text">
                      <p>
                      Content marketing involves creating and distributing valuable, relevant, and consistent content to attract and engage a target audience. It aims to drive profitable customer action by providing information, entertainment, or solutions that address audience needs or interests. Key elements include content strategy development, creation of diverse content formats such as articles, videos, infographics, and podcasts, distribution across various channels like blogs, social media, email, and SEO optimization. Effective content marketing builds brand awareness, fosters trust, and nurtures relationships with customers, ultimately driving conversions and brand loyalty.
                      </p>
                    </div>
                  </div>{" "}
                  {/* list-expertise__item */}
                  <div className="grid-list-items__item list-items__item">
                    <div className="grid-list-items__title list-items__item-header">
                      <h3 className="list-items__item-title">
                        Research &amp; Discovery
                      </h3>
                    </div>
                    <div className="grid-list-items__text list-items__item-text">
                      <p>
                      Research and discovery in content marketing involve the systematic gathering and analysis of information to understand target audiences, industry trends, and competitors. It includes market research, audience segmentation, keyword research, and competitive analysis. Research helps identify audience preferences, pain points, and interests, informing content strategy development and content creation. Discovery involves uncovering unique insights and opportunities that can differentiate content and drive engagement. By continuously researching and discovering new information, content marketers can adapt strategies, optimize content, and stay ahead in a competitive landscape.
                      </p>
                    </div>
                  </div>{" "}
                  {/* list-expertise__item */}
                </div>{" "}
                {/* grid-list-items */}
              </div>{" "}
              {/* end s-expertise__content-main */}
              <div className="s-expertise__content-btn grid-section-split__bottom">
                <Link to={"/services"} className="btn btn--stroke u-fullwidth">
                  View All Services
                </Link>
              </div>{" "}
              {/* end s-about__content-btn */}
            </div>{" "}
            {/* end grid-blck*/}
          </div>{" "}
          {/* end s-expertise__content */}
        </section>{" "}
        {/* end s-expertise */}
        {/* clients
        ----------------------------------------------- */}
        <section id="clients" className="s-clients">
          <div className="row s-clients__content-block width-sixteen-col">
            <div className="column xl-12 grid-block grid-section-split">
              <div className="section-header grid-section-split__header">
                <div className="text-pretitle">Clients</div>
                <h2 className="text-display-title">
                  I have had the privilege of learning these technologies.
                </h2>
              </div>{" "}
              {/* end section-header */}
              <div className="grid-section-split__primary">
                <p className="lead">
                React is a popular JavaScript library for building user interfaces, developed by Facebook. It enables developers to create interactive and dynamic web applications with ease. React uses a component-based architecture, where UI elements are encapsulated into reusable and modular components. This approach promotes code reusability, maintainability, and scalability. React utilizes a virtual DOM (Document Object Model) to efficiently update and render UI components, resulting in faster performance. It also provides features like JSX (JavaScript XML) syntax for writing HTML-like code within JavaScript, state management through props and state, and a rich ecosystem of libraries and tools (such as React Router and Redux) for building robust applications. With its simplicity, flexibility, and strong community support, React has become a go-to choice for frontend development, powering many popular web applications and websites.
                </p>
                <p>
                Node.js is a powerful runtime environment that allows developers to execute JavaScript code server-side, outside the browser. Built on Chrome's V8 JavaScript engine, Node.js enables the development of scalable and high-performance network applications. One of its key features is non-blocking, event-driven architecture, which allows asynchronous I/O operations, making it ideal for building real-time applications like chat applications, streaming services, and APIs. Node.js has a rich ecosystem of packages and modules available through npm (Node Package Manager), enabling developers to easily extend its functionality. It's commonly used for backend development, creating web servers, RESTful APIs, and microservices. Node.js is known for its lightweight and efficient nature, making it a preferred choice for building modern, scalable, and fast web applications.
                </p>
              </div>{" "}
              {/* end grid-section-split__primary */}
            </div>{" "}
            {/* end column */}
          </div>{" "}
          {/* end row */}
          <div className="row s-clients__content-block width-sixteen-col">
            <div className="column xl-12">
              <div className="clients-list">
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://www.olcbd.net/wp-content/uploads/2018/05/html-800x445.jpg" alt="" />
                  </a>
                </div>
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://1000logos.net/wp-content/uploads/2020/09/CSS-Logo.png" alt="" />
                  </a>
                </div>
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://1000logos.net/wp-content/uploads/2020/09/JavaScript-Logo-2048x1280.png" alt="" />
                  </a>
                </div>
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://oneteamsolutions.in/blogoneteam/wp-content/uploads/2020/05/REACT-JS-KOCHI.png" alt="" />
                  </a>
                </div>
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://www.taniarascia.com/static/517c02bd875932e2a959488763695b28/92ab1/node.png" alt="" />
                  </a>
                </div>
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://v5.getbootstrap.com/docs/5.0/assets/brand/bootstrap-logo-shadow.png" alt="" />
                  </a>
                </div>
                <div className="column clients-list__item">
                  <a href="#0">
                    <img src="https://www.pngitem.com/pimgs/m/31-312155_c-programming-language-logo-hd-png-download.png" alt="" />
                  </a>
                </div>
                <div className="column clients-list__item">
                  <a href="#0">
                    <img src="https://e7.pngegg.com/pngimages/520/669/png-clipart-c-logo-c-programming-language-computer-icons-computer-programming-programming-miscellaneous-blue.png" alt="" />
                  </a>
                </div>
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://brandlogos.net/wp-content/uploads/2021/11/java-logo.png" alt="" />
                  </a>
                </div>
                <div className="clients-list__item">
                  <a href="#0">
                    <img src="https://www.pinclipart.com/picdir/middle/534-5345877_python-logo-clipart.png" alt="" />
                  </a>
                </div>
              </div>{" "}
              {/* end clients-list */}
            </div>{" "}
            {/* end column */}
          </div>{" "}
          {/* end row */}
          
             
        {/* end s-clients */}
      </section>
      </section>

    </div >
  )
}
