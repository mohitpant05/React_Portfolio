import React from 'react'
import NavBar from './NavBar'
import { Outlet } from 'react-router-dom'
import Footer from './Footer'
import Home from './Home'
import About from './About'
import Services from './Services'
import Contact from './Contact'

export default function Master() {
    return (
        <div>
            <NavBar />
            <Outlet />
            <Footer />
        </div>
    )
}
