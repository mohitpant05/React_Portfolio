import React from 'react'

export default function Services() {
  return (<>

        <section id="content" className="s-content">
          <section className="s-pageheader pageheader">
            <div className="row">
              <div className="column xl-12">
                <h1 className="page-title">
                  <span className="page-title__small-type text-pretitle">
                    Services
                  </span>
                  High-Impact Services
                </h1>
              </div>
            </div>
          </section>{" "}
          {/* pageheader */}
          <section className="s-pagecontent pagecontent">
            <div className="row pageintro">
              <div className="column xl-6 lg-12">
                <h2 className="text-display-title">
                  High-impact services to help your business
                </h2>
              </div>
              <div className="column xl-6 lg-12 u-flexitem-x-right">
                <p className="lead">
                In today's fast-paced digital landscape, businesses face ever-evolving challenges. As a software engineer, I've witnessed firsthand the transformative power of technology in driving business growth and efficiency. By harnessing high-impact services, businesses can unlock new opportunities, streamline operations, and stay ahead of the competition. Here, I'll outline some key services that can propel your business to success
                </p>
              </div>
            </div>{" "}
            {/* pageintro */}
            <div className="row">
              <div className="column xl-12 grid-block">
                <div className="grid-full grid-list-items list-items show-ctr">
                  <div className="grid-list-items__item list-items__item">
                    <div className="list-items__item-header">
                      <h3 className="list-items__item-title">Digital Marketing</h3>
                    </div>
                    <div className="list-items__item-text">
                      <p>
                      Digital marketing encompasses various strategies and channels to promote products or services online. It leverages platforms such as social media, search engines, email, and websites to reach and engage target audiences. Key components include search engine optimization (SEO), content marketing, social media marketing, email marketing, and pay-per-click (PPC) advertising. With its ability to target specific demographics, track performance metrics, and optimize campaigns in real-time, digital marketing offers businesses a cost-effective way to increase brand awareness, generate leads, and drive conversions in today's interconnected world.
                      </p>
                      <ul className="list-services">
                        <li>Targeted Reach</li>
                        <li>Measurable Results</li>
                        <li>Cost-Effectiveness</li>
                      </ul>
                    </div>
                  </div>{" "}
                  {/* end list-items__item */}
                  <div className="grid-list-items__item list-items__item">
                    <div className="list-items__item-header">
                      <h3 className="list-items__item-title">
                        Social Media Marketing
                      </h3>
                    </div>
                    <div className="list-items__item-text">
                      <p>
                      Social media marketing utilizes social platforms like Facebook, Instagram, Twitter, and LinkedIn to connect with target audiences and promote products or services. It involves creating and sharing engaging content, interacting with followers, and running targeted advertising campaigns. Key strategies include audience segmentation, content creation, engagement tactics, and performance analysis. With its ability to reach billions of users globally, social media marketing offers businesses a powerful tool to increase brand visibility, drive website traffic, generate leads, and foster customer relationships. It provides valuable insights and analytics to measure campaign performance and optimize strategies for maximum effectiveness. By leveraging the reach and engagement potential of social media, businesses can build brand authority, cultivate loyal communities, and ultimately, drive business growth in today's digital age.
                      </p>
                      <ul className="list-services">
                        <li>Precise audience targeting</li>
                        <li>Engagement and interaction</li>
                        <li>Data-Driven Insights and Optimization</li>
                      </ul>
                    </div>
                  </div>{" "}
                  {/* end list-items__item */}
                  <div className="grid-list-items__item list-items__item">
                    <div className="list-items__item-header">
                      <h3 className="list-items__item-title">Content Marketing</h3>
                    </div>
                    <div className="list-items__item-text">
                      <p>
                      Content marketing is a strategic approach that focuses on creating and distributing valuable, relevant, and consistent content to attract and retain a target audience. Unlike traditional advertising, which directly promotes products or services, content marketing aims to provide value to consumers by addressing their needs, interests, and pain points. 
                      </p>
                      <ul className="list-services">
                        <li>Audience-Centric Approach</li>
                        <li>Quality Content Creation</li>
                        <li>Distribution and Promotion</li>
                      </ul>
                    </div>
                  </div>{" "}
                  {/* end list-items__item */}
                 
                  {/* end list-items__item */}
                  <div className="grid-list-items__item list-items__item">
                    <div className="list-items__item-header">
                      <h3 className="list-items__item-title">
                        Search Engine Optimization
                      </h3>
                    </div>
                    <div className="list-items__item-text">
                      <p>
                      Search Engine Optimization (SEO) is a crucial digital marketing strategy aimed at improving a website's visibility and ranking on search engine results pages (SERPs). By optimizing various aspects of a website, businesses can attract organic (non-paid) traffic from search engines like Google, Bing, and Yahoo. The primary goal of SEO is to enhance a website's relevance and authority in the eyes of search engines, ultimately driving more qualified traffic and increasing conversion rates.
                      </p>
                      <ul className="list-services">
                        <li>Increased Visibility</li>
                        <li>Quality Traffic</li>
                        <li>Long-Term Sustainability</li>
                      </ul>
                    </div>
                  </div>{" "}
                  {/* end list-items__item */}
                  
                  {/* end list-items__item */}
                 
                  {/* end list-items__item */}
                </div>{" "}
                {/* grid-list-items */}
              </div>{" "}
              {/* end grid-block*/}
            </div>{" "}
            {/* end row */}
          </section>{" "}
          {/* pagecontent */}
          
        {/* s-content*/}
        {/* # cta
    ================================================== */}
        <section id="cta" className="s-cta">
          <div className="row row-x-center text-center">
            <div className="column xl-8 lg-12">
              <div className="s-cta__content">
                <h2 className="text-display-title">
                  Get started with a consultation today.
                </h2>
                <p className="lead">
                  I also provide consultation for businesses looking to leverage technology and digital marketing to drive growth and innovation. Let's discuss how I can help you achieve your business goals.
                </p>
                <a href="contact.html" className="btn btn--primary">
                  Let's Work Together
                </a>
              </div>
            </div>
          </div>
        </section>
       </section>
      </>

    
  )
}
